const bookings = [];

document.addEventListener("DOMContentLoaded", () => {
    const bookingForm = document.getElementById("bookingForm");
    bookingForm.addEventListener("submit", handleBooking);
});

function handleBooking(event) {
    event.preventDefault();
    const facility = document.getElementById("facility").value;
    const date = document.getElementById("date").value;
    const startTime = document.getElementById("startTime").value;
    const endTime = document.getElementById("endTime").value;

    if (!isValidBookingDate(date, startTime)) {
        alert("Booking Failed, Invalid Date/Time");
        return;
    }

    const bookingAmount = calculateBookingAmount(facility, startTime, endTime);
    if (bookingAmount === null) {
        alert("Booking Failed, Invalid Facility or Time");
        return;
    }

    const isAvailable = checkAvailability(facility, date, startTime, endTime);
    if (!isAvailable) {
        alert("Booking Failed, Already Booked");
        return;
    }

    bookings.push({
        facility,
        date,
        startTime,
        endTime,
        bookingAmount,
    });
    if(facility== "")
    {
        alert("Please fill all the details")
    }

    displayOutput(`Booked, Rs. ${bookingAmount}`);
    displayBookedDetails()
}

function isValidBookingDate(date, startTime) {
    const currentDate = new Date();
    const selectedDate = new Date(`${date} ${startTime}`);
    return selectedDate >= currentDate;
}

function calculateBookingAmount(facility, startTime, endTime) {
    const startHour = parseInt(startTime.split(":")[0]);
    const endHour = parseInt(endTime.split(":")[0]);

    if (facility === "clubhouse") {
        if ((startHour >= 10 && endHour <= 16))  {
            return 100 * (endHour - startHour);
        }else if( (startHour >= 16 && endHour <= 22))
        {
            return 500 * (endHour - startHour);
        }
       
    } else if (facility === "tennisCourt") {
        if ((startHour >= 10 && endHour <= 22))  {
        return 50 * (endHour - startHour);
        }
    }
    

    return null;
}

function checkAvailability(facility, date, startTime, endTime) {
    const isAvailable = bookings.every(booking => {
        if (booking.facility !== facility || booking.date !== date) {
            return true;
        }

        const bookedStartTime = new Date(`2023-08-04 ${booking.startTime}`);
        const bookedEndTime = new Date(`2023-08-04 ${booking.endTime}`);
        const selectedStartTime = new Date(`2023-08-04 ${startTime}`);
        const selectedEndTime = new Date(`2023-08-04 ${endTime}`);

        return selectedEndTime <= bookedStartTime || selectedStartTime >= bookedEndTime;
    });

    return isAvailable;
}

function displayBookedDetails() {
    const bookingsList = document.getElementById("bookingsList");
    bookingsList.innerHTML = ""; 

    bookings.forEach(booking => {
        const listItem = document.createElement("li");
        listItem.textContent = `${booking.facility}, ${booking.date}, ${booking.startTime} - ${booking.endTime}, Rs. ${booking.bookingAmount}`;
        bookingsList.appendChild(listItem);
    });

}

function displayOutput(message) {
    const outputDiv = document.getElementById("output");
    outputDiv.textContent = message;
}
